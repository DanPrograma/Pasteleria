import React, { useState } from 'react'; // Importamos useState
import { Link } from 'react-router-dom';
import { Container, Row, Col, Form, Button, Alert } from 'react-bootstrap';

const Contacto = () => {
  // 1. Estados para los campos y errores
  const [email, setEmail] = useState('');
  const [mensaje, setMensaje] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    setError(''); // Limpiamos errores previos

    // 2. Validación: Debe terminar en @duocuc.cl
    if (!email.toLowerCase().endsWith('@duocuc.cl')) {
      setError('Debes usar un correo válido (@duocuc.cl)');
      return;
    }

    // Si pasa la validación
    alert("¡Mensaje enviado con éxito! Te contactaremos pronto.");
    
    // Opcional: Limpiar el formulario
    setEmail('');
    setMensaje('');
  };

  return (
    <Container className="py-5 flex-grow-1">
      <Row className="justify-content-center">
        <Col xs={12} md={8} lg={6}>
          <div className="contact-card p-4 p-md-5 shadow-sm border-0 rounded-4 bg-white">
            <div className="text-center mb-4">
              <div className="contact-icon mx-auto mb-3" style={{ fontSize: '2rem' }}>
                ✉️
              </div>
              <h1 className="h4 fw-bold mb-1" style={{ color: '#c06c84' }}>
                Contáctanos por correo
              </h1>
              <p className="text-muted mb-0">
                Respondiendo lo antes posible. Cuéntanos tu solicitud.
              </p>
            </div>

            {/* 3. Mostrar alerta de error si existe */}
            {error && <Alert variant="danger">{error}</Alert>}

            <Form onSubmit={handleSubmit}>
              <Form.Group className="mb-3" controlId="correo">
                <Form.Label className="fw-semibold">Correo Electrónico</Form.Label>
                <Form.Control 
                  type="email" 
                  size="lg" 
                  placeholder="nombre@duocuc.cl" 
                  required 
                  value={email}
                  onChange={(e) => setEmail(e.target.value)} // Vinculamos el estado
                />
              </Form.Group>

              <Form.Group className="mb-3" controlId="mensaje">
                <Form.Label className="fw-semibold">Déjanos tu comentario</Form.Label>
                <Form.Control 
                  as="textarea" 
                  rows={4} 
                  placeholder="Escribe tu mensaje aquí..." 
                  required 
                  value={mensaje}
                  onChange={(e) => setMensaje(e.target.value)} // Vinculamos el estado
                />
                <Form.Text className="text-muted">
                  Evita incluir datos sensibles. Te responderemos al correo indicado.
                </Form.Text>
              </Form.Group>

              <Button 
                type="submit" 
                className="w-100 btn-lg border-0"
                style={{ backgroundColor: '#c06c84' }}
              >
                Enviar mensaje
              </Button>

              <div className="text-center mt-4">
                <Link to="/" className="small text-decoration-none" style={{ color: '#c06c84' }}>
                  Volver al inicio
                </Link>
              </div>
            </Form>
          </div>
        </Col>
      </Row>
    </Container>
  );
};

export default Contacto;