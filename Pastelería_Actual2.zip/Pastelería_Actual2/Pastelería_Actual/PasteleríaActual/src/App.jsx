import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.bundle.min.js";
import "bootstrap-icons/font/bootstrap-icons.css";
import "./App.css";
import Productos from "./pages/Productos";
//import products from "/src/data/Products.json";
import Navbar from "./components/NavBar.jsx";
import Inicio from "./pages/Inicio.jsx";
import Footer from "./components/Footer.jsx";
import Contacto from "./pages/Contacto.jsx";

function App() {
  const clearCart = () => {
    // TODO: tu lógica para vaciar carrito
    console.log("Vaciar carrito");
  };

  return (
    <Router>
     
     {/* Estas clases de Bootstrap hacen la magia*/}
    <div className="d-flex flex-column min-vh-100">
      <Navbar />
      
      {/* El contenido principal debe tener flex-grow-1 para empujar al footer */}
      <main className="flex-grow-1">
        {/* Aquí van tus componentes: Carrusel, Filtro, Productos, etc. */}

        <Routes>
          <Route path="/" element={<Inicio />} />
          <Route path="/productos" element={<Productos />} />
          <Route path="/contacto" element={<Contacto />} />
        </Routes>
      </main>

      <Footer />
    </div>

    
    </Router>
  );
}

export default App;
